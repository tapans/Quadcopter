package pack;

import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.DefaultCaret;

/**
 * Responsible for creating all graphical related stuff i.e. commandline,
 * console, buttons.. Communicates directly with SerialCommunication to transmit
 * and receive data between the microcontroller via USART.
 * 
 * @author Aaron, Rashaad, Tapan
 * 
 */
public class GUI extends JFrame implements ActionListener, KeyListener,
		ChangeListener {

	// Sensor Data 
	public static float accl_x = 100;
	public static float accl_y = 0;
	public static float accl_z = 0;
	public static float gyro_x = 0;
	public static float gyro_y = 0;
	public static float gyro_z = 0;
	public static float rangeFinder = 0;
	
	private JTextField BaudRateText;
	private JComboBox portsCombo;
	private JTextField commandlineText;
	private JComboBox AllMotorsCombo;
	private String[] AllMotorStr = { "5", "10", "15" };
	private JTextArea consoleArea;
	private String[] values = new String[5];
	private int[] motorSpeed = new int[4];
	private int height;
	private JButton sendButton;
	private SerialCommunication rs232;
	private JFrame motorsFrame;
	private JFrame rangefinderFrame;
	private JFrame graphFrame;
	private JMenuItem graph;
	private JMenuItem rangefinder;
	private JMenuItem motors;
	private JMenuItem exit;
	private JMenu file;
	private JMenuBar menubar;
	private JSlider GraphIntervalSlider;
	private JSlider motor1Slider;
	private JSlider motor2Slider;
	private JSlider motor3Slider;
	private JSlider motor4Slider;
	private JSlider heightSlider;
	private JLabel motor1Label;
	private JLabel motor2Label;
	private JLabel motor3Label;
	private JLabel motor4Label;
	private JLabel rangefinderLabel;
	private String[] accl_data;
	private String[] gyro_data;
	private String[] rangeFinder_data;

	/**
	 * Create and show the GUI. Also instantiate the SerialCommunication and
	 * have it listening for responses to commands.
	 * 
	 * @param name
	 */
	public GUI(String name) {
		super(name);

		/* Setup Communication Stuff */
		this.rs232 = new SerialCommunication(this);
		HashSet<String> availablePorts = this.rs232.getPorts();
		String[] ports = availablePorts.toArray(new String[availablePorts.size()]);
		/* End Comm Setup */

		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Read settings file and set each line to corresponding string value
		// index

		List<String> length = new ArrayList<String>();
		String s;

		try {
			BufferedReader br = new BufferedReader(new FileReader("settings"));
			while ((s = br.readLine()) != null) {
				length.add(s);

			}
			for (int i = 0; i < length.size(); i++) {
				values[i] = length.get(i);
			}

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			System.out.println("Exception: " + e);
		}

		// Create a menu bar
		this.menubar = new JMenuBar();
		this.setJMenuBar(menubar);

		// Create file, motor and exit menu items
		this.file = new JMenu("File");
		this.menubar.add(file);
		this.motors = new JMenuItem("Motors");
		this.motors.setActionCommand("motors");
		this.motors.addActionListener(this);
		this.rangefinder = new JMenuItem("Range Finder");
		this.rangefinder.setActionCommand("range finder");
		this.rangefinder.addActionListener(this);
		this.graph = new JMenuItem("Graphs");
		this.graph.setActionCommand("graph");
		this.graph.addActionListener(this);
		this.exit = new JMenuItem("Exit");
		this.exit.setActionCommand("exit");
		this.exit.addActionListener(this);
		this.file.add(graph);
		this.file.add(motors);
		this.file.add(rangefinder);
		this.file.add(exit);

		// set the frame dimensions
		this.setSize(700, 700);

		JPanel main = new JPanel();
		main.setLayout(new BoxLayout(main, BoxLayout.PAGE_AXIS));
		main.setBorder(BorderFactory
				.createTitledBorder("RS-232 Serial Communication"));

		// create a settings panel
		JPanel set = new JPanel();
		set.setLayout(new FlowLayout(FlowLayout.LEFT));
		set.setBorder(BorderFactory.createTitledBorder("Settings"));
		JLabel baudrateLabel = new JLabel("Set Baud Rate");
		this.BaudRateText = new JTextField(10);
		BaudRateText.setText(values[1]);

		// create the connect panel
		JPanel con = new JPanel();
		con.setLayout(new FlowLayout(FlowLayout.LEFT));
		con.setBorder(BorderFactory.createTitledBorder("Connection"));
		JLabel portLabel = new JLabel("Select Port:");
		JButton connect = new JButton("Connect");
		JButton disconnect = new JButton("Disconnect");
		JButton saveButton = new JButton("Save");

		// set the action to disconnect
		disconnect.setActionCommand("disconnect");
		disconnect.addActionListener(this);

		// set the action to connect
		connect.setActionCommand("connect");
		connect.addActionListener(this); // enable listener

		// set the action to save
		saveButton.setActionCommand("save");
		saveButton.addActionListener(this); // enable listener

		// create commandline
		JPanel cmd = new JPanel();
		cmd.setLayout(new FlowLayout(FlowLayout.LEFT));
		cmd.setBorder(BorderFactory.createTitledBorder("Command"));
		JLabel cmdLabel = new JLabel("Command:");
		this.commandlineText = new JTextField(35);
		this.sendButton = new JButton("Send");
		this.sendButton.setActionCommand("send");
		this.sendButton.addActionListener(this);
		JButton clearBtn = new JButton("Clear");
		clearBtn.setActionCommand("Clear");
		clearBtn.addActionListener(this);

		cmd.add(cmdLabel);
		cmd.add(this.commandlineText);
		cmd.add(this.sendButton);
		cmd.add(clearBtn);

		// create the console
		this.consoleArea = new JTextArea(15, 54);
		this.consoleArea.setLineWrap(true);
		consoleArea.setBackground(Color.BLACK);
		consoleArea.setForeground(Color.GREEN);
		consoleArea.setEditable(false);
		consoleArea.setSize(new Dimension(300, 300));
		JScrollPane scrollPane = new JScrollPane(consoleArea,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		// Auto-scroll the console
		DefaultCaret caret = (DefaultCaret) consoleArea.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		consoleArea.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1,
				Color.black));
		consoleArea.setVisible(true);

		JPanel consolePanel = new JPanel();
		consolePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		consolePanel.setBorder(BorderFactory
				.createTitledBorder("Console Input/Output"));

		this.portsCombo = new JComboBox(ports);
		// portsCombo.setSelectedIndex(Integer.parseInt(values[0]));
		// portsCombo.setSelectedIndex(0);

		set.add(baudrateLabel);
		set.add(BaudRateText);

		con.add(portLabel);
		con.add(portsCombo);
		con.add(connect);
		// con.add(disconnect);
		con.add(saveButton);

		consolePanel.add(scrollPane);

		main.add(set);
		main.add(con);
		main.add(cmd);
		main.add(consolePanel);

		this.add(main);
		this.setVisible(true);

		// Add Key Listern for commandline Text
		this.commandlineText.addKeyListener(this);

	}

	public int getBuadRate() {
		return Integer.parseInt(this.values[1]);
	}

	public int getScaler() {
		return this.GraphIntervalSlider.getValue();
	}

	/**
	 * Append Strings to the console showing a log of all the commands that were
	 * typed (like a terminal)
	 */
	public void appendToConsole() {

		String command = this.commandlineText.getText();
		this.commandlineText.setText("");
		this.consoleArea.append("<command>: " + command + "\n");
		try {
			this.rs232.write(command);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Sending command: " + command + "\n");

	}

	public void appendToConsole(String s) {
		this.consoleArea.append(s);
	}

	private void clearConsole() {
		this.consoleArea.setText("");
	}

	/**
	 * Responses from the SerialReader are directed here upon read completion.
	 * 
	 * @param returned
	 */
	public void handleResponse(String returned) {

		if (returned.equalsIgnoreCase("ACK")) {
			this.consoleArea.append(">>ACKNOWLEDGE received..\n");
			this.consoleArea.append(">>Ready to communicate\n");
		} else if (returned.trim().matches("^\\(aX\\)(.*)$")) {

			this.accl_data = returned.split(" ");

			GUI.accl_x = Float.parseFloat(accl_data[1]);
			GUI.accl_y = Float.parseFloat(accl_data[3]);
			GUI.accl_z = Float.parseFloat(accl_data[5]);
			this.consoleArea.append("<response>" + returned.trim() + "\n");

		} else if (returned.trim().matches("^\\(gX\\)(.*)$")) {

			this.gyro_data = returned.split(" ");
			
			GUI.gyro_x = Float.parseFloat(gyro_data[1]);
			GUI.gyro_y = Float.parseFloat(gyro_data[3]);
			GUI.gyro_z = Float.parseFloat(gyro_data[5]);

			this.consoleArea.append("<response>" + returned.trim() + "\n");

		} else if (returned.trim().matches("^\\(rF\\)(.*)$")) {

			this.rangeFinder_data = returned.split(" ");
			GUI.rangeFinder = Float.parseFloat(rangeFinder_data[1]);
			//System.out.println(GUI.rangeFinder);
			
			this.rangefinderLabel.setText(GUI.rangeFinder + "cm");
			
			this.consoleArea.append("<response>" + returned.trim() + "\n");

		}else {
			this.consoleArea.append("<response>" + returned + "\n");
		}
	}

	/**
	 * Listens for ActionEvent issued from the GUI
	 */
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();

		if (action == "connect") {
			try {
				String port = this.portsCombo.getSelectedItem().toString();
				this.rs232.connect(port);
				if (this.rs232.isConnected()) {
					this.consoleArea.append("..Attempting to connect on "
							+ port + "\n");
					Thread.sleep(700);
					this.rs232.write("HELO root root"); // ask for Acknowledge
														// using
														// username/password
				}

			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} else if (action == "send") {
			motorSpeed[0] = 30;
			this.appendToConsole();

		} else if (action == "exit") {

			System.exit(0);
		} else if (action == "motors") {

			// Main motor panel
			this.motorsFrame = new JFrame("Motors");
			JPanel motorsPanel = new JPanel();
			;
			motorsPanel.setLayout(new BoxLayout(motorsPanel,
					BoxLayout.PAGE_AXIS));
			motorsPanel.setBorder(BorderFactory.createTitledBorder("Motors"));

			JButton Motorsconnect = new JButton("Initialize PWM & ESCs");
			JButton Motorsdisconnect = new JButton("Deactivate");

			// set the action to disconnect
			Motorsdisconnect.setActionCommand("deactivate");
			Motorsdisconnect.addActionListener(this);

			// set the action to connect
			Motorsconnect.setActionCommand("initialize");
			Motorsconnect.addActionListener(this); // enable listener

			// Motor 1 Panel
			JPanel motor1Panel = new JPanel();

			motor1Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
			motor1Panel.setBorder(BorderFactory
					.createTitledBorder("North Motor"));
			this.motor1Slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
			this.motor1Slider.addChangeListener(this);
			this.motor1Slider.setMajorTickSpacing(25);
			this.motor1Slider.setMinorTickSpacing(5);
			this.motor1Slider.setPaintTicks(true);
			this.motor1Slider.setPaintLabels(true);
			this.motor1Slider.setName("motor1");
			this.motor1Label = new JLabel("Speed: " + motor1Slider.getValue());
			motor1Panel.add(motor1Slider);
			motor1Panel.add(motor1Label);

			// Motor 2 Panel
			JPanel motor2Panel = new JPanel();
			motor2Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
			motor2Panel.setBorder(BorderFactory
					.createTitledBorder("South Motor"));
			this.motor2Slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
			this.motor2Slider.addChangeListener(this);
			this.motor2Slider.setMajorTickSpacing(25);
			this.motor2Slider.setMinorTickSpacing(5);
			this.motor2Slider.setPaintTicks(true);
			this.motor2Slider.setPaintLabels(true);
			this.motor2Slider.setName("motor2");
			this.motor2Label = new JLabel("Speed: " + motor2Slider.getValue());
			motor2Panel.add(motor2Slider);
			motor2Panel.add(motor2Label);

			// Motor 3 Panel
			JPanel motor3Panel = new JPanel();
			motor3Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
			motor3Panel.setBorder(BorderFactory
					.createTitledBorder("East Motor"));
			this.motor3Slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
			this.motor3Slider.addChangeListener(this);
			this.motor3Slider.setMajorTickSpacing(25);
			this.motor3Slider.setMinorTickSpacing(5);
			this.motor3Slider.setPaintTicks(true);
			this.motor3Slider.setPaintLabels(true);
			this.motor3Slider.setName("motor3");
			this.motor3Label = new JLabel("Speed: " + motor3Slider.getValue());
			motor3Panel.add(motor3Slider);
			motor3Panel.add(motor3Label);

			// Motor 4 Panel
			JPanel motor4Panel = new JPanel();
			motor4Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
			motor4Panel.setBorder(BorderFactory
					.createTitledBorder("West Motor"));
			this.motor4Slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
			this.motor4Slider.addChangeListener(this);
			this.motor4Slider.setMajorTickSpacing(25);
			this.motor4Slider.setMinorTickSpacing(5);
			this.motor4Slider.setPaintTicks(true);
			this.motor4Slider.setPaintLabels(true);
			this.motor4Slider.setName("motor4");
			this.motor4Label = new JLabel("Speed: " + motor4Slider.getValue());
			motor4Panel.add(motor4Slider);
			motor4Panel.add(motor4Label);

			// All Motors panel
			JPanel allmotorsPanel = new JPanel();
			allmotorsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
			allmotorsPanel.setBorder(BorderFactory
					.createTitledBorder("All Motors"));

			JButton decreaseButton = new JButton("<");
			decreaseButton.setActionCommand("decrease");
			decreaseButton.addActionListener(this);

			JButton increaseButton = new JButton(">");
			increaseButton.setActionCommand("increase");
			increaseButton.addActionListener(this);

			this.AllMotorsCombo = new JComboBox(AllMotorStr);
			this.AllMotorsCombo.setSelectedIndex(0);

			allmotorsPanel.add(decreaseButton);
			allmotorsPanel.add(increaseButton);
			allmotorsPanel.add(AllMotorsCombo);

			this.motorsFrame.add(motorsPanel);
			motorsPanel.add(Motorsconnect);
			motorsPanel.add(motor1Panel);
			motorsPanel.add(motor2Panel);
			motorsPanel.add(motor3Panel);
			motorsPanel.add(motor4Panel);
			motorsPanel.add(allmotorsPanel);
			motorsPanel.add(Motorsdisconnect);
			motorsFrame.setLocation(160, 160); // Default starting coordinates
												// of frame
			motorsFrame.setSize(480, 540);
			motorsFrame.setVisible(true);

		} else if (action == "range finder") {
			this.rangefinderFrame = new JFrame("Range Finder");
			JPanel rangefinderPanel = new JPanel();

			rangefinderPanel.setLayout(new BoxLayout(rangefinderPanel,
					BoxLayout.PAGE_AXIS));
			rangefinderPanel.setBorder(BorderFactory
					.createTitledBorder("Range Finder"));

			JButton RangeFinderconnect = new JButton("Initialize");
			JButton RangeFinderdisconnect = new JButton("Deactivate");

			// set the action to disconnect
			RangeFinderdisconnect.setActionCommand("deactivate rangefinder");
			RangeFinderdisconnect.addActionListener(this);

			// set the action to connect
			RangeFinderconnect.setActionCommand("initialize rangefinder");
			RangeFinderconnect.addActionListener(this); // enable listener

			// height panel
			JPanel verticalheightPanel = new JPanel();
			verticalheightPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
			verticalheightPanel.setBorder(BorderFactory
					.createTitledBorder("Vertical height"));

			this.heightSlider = new JSlider(JSlider.VERTICAL, 0, 100, 0);
			this.heightSlider.addChangeListener(this);
			this.heightSlider.setMajorTickSpacing(25);
			this.heightSlider.setMinorTickSpacing(5);
			this.heightSlider.setPaintTicks(true);
			this.heightSlider.setPaintLabels(true);
			this.heightSlider.setName("height");

			this.rangefinderLabel = new JLabel("Distance from object: "
					+ GUI.rangeFinder);
			this.rangefinderLabel.setFont(new Font("Arial", 1, 100));
			// verticalheightPanel.add(heightSlider);
			verticalheightPanel.add(rangefinderLabel);
			this.rangefinderFrame.add(rangefinderPanel);
			// rangefinderPanel.add(RangeFinderconnect);
			rangefinderPanel.add(rangefinderLabel);
			// rangefinderPanel.add(RangeFinderdisconnect);
			rangefinderFrame.setLocation(160, 160); // Default starting
													// coordinates of frame
			rangefinderFrame.setSize(480, 400);
			rangefinderFrame.setVisible(true);
		} else if (action == "graph") {
			
			new Chart(this);
			
			/*
			this.graphFrame = new JFrame("Gyroscope");

			Graph g = new Graph();
			this.graphFrame.setBackground(Color.BLACK);

			this.graphFrame.add(g);

			graphFrame.setLocation(100, 0); // Default starting coordinates of
											// frame
			graphFrame.setSize(725, 800);
			graphFrame.setVisible(true);
			*/
			

		} else if (action == "save") {
			values[0] = "" + portsCombo.getSelectedIndex();
			values[1] = "" + BaudRateText.getText();
			try {
				BufferedWriter bw = new BufferedWriter(new FileWriter(
						"settings"));
				bw.write(values[0] + "\n");
				bw.write(values[1]);
				bw.close();
			} catch (IOException s) {
				s.printStackTrace();
			}
		} else if (action.equalsIgnoreCase("decrease")) {
			motor1Slider.setValue(motor1Slider.getValue()
					- (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor2Slider.setValue(motor2Slider.getValue()
					- (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor3Slider.setValue(motor3Slider.getValue()
					- (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor4Slider.setValue(motor4Slider.getValue()
					- (AllMotorsCombo.getSelectedIndex() + 1) * 5);
		} else if (action.equalsIgnoreCase("increase")) {
			motor1Slider.setValue(motor1Slider.getValue()
					+ (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor2Slider.setValue(motor2Slider.getValue()
					+ (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor3Slider.setValue(motor3Slider.getValue()
					+ (AllMotorsCombo.getSelectedIndex() + 1) * 5);
			motor4Slider.setValue(motor4Slider.getValue()
					+ (AllMotorsCombo.getSelectedIndex() + 1) * 5);
		} else if (action.equalsIgnoreCase("clear")) {
			this.clearConsole();
		} else if (action.equalsIgnoreCase("disconnect")) {
			this.rs232.disconnect();
		} else if (action.equalsIgnoreCase("initialize")) {
			try {
				this.rs232.write("init pwm");
				this.rs232.write("init escs");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (action.equalsIgnoreCase("deactivate")) {
			try {
				this.rs232.write("deactivate");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
		if (key == KeyEvent.VK_ENTER) {
			// Toolkit.getDefaultToolkit().beep();

			if (this.commandlineText.getText().equalsIgnoreCase("clear")) {
				this.clearConsole();
				this.commandlineText.setText("");
			} else {
				this.appendToConsole();
				this.commandlineText.setText("");
			}
		}
	}

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
	}

	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	// Check if sliders have changed states
	// Check if sliders have changed states
	public void stateChanged(ChangeEvent e) {

		JSlider source = (JSlider) e.getSource();
		float multiplier = (float) ((int) source.getValue() / 100.00);

		if (source.getName().equals("motor1")) {
			this.motor1Label.setText("Speed :" + (int) source.getValue());
			try {
				this.rs232.write("set speed north "
						+ String.format("%.2f", multiplier));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if (source.getName().equals("motor2")) {
			this.motor2Label.setText("Speed :" + (int) source.getValue());
			try {
				this.rs232.write("set speed south "
						+ String.format("%.2f", multiplier));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if (source.getName().equals("motor3")) {
			this.motor3Label.setText("Speed :" + (int) source.getValue());
			try {
				this.rs232.write("set speed east "
						+ String.format("%.2f", multiplier));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if (source.getName().equals("motor4")) {
			this.motor4Label.setText("Speed :" + (int) source.getValue());
			try {
				this.rs232.write("set speed west "
						+ String.format("%.2f", multiplier));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GUI("QuadCopter USART Communication");

	}

}
