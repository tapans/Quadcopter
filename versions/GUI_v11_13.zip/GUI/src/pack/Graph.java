package pack;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class Graph extends JPanel {

	
	
	//x graph
	private int ox = 5;
	private int oy = 200;

	//y graph
	private int ox2 = 5;
	private int oy2 = 400;
	
	//z graph
	private int ox3 = 5;
	private int oy3 = 600;
	
	private int[] gx = new int[500];
	private int[] gy = new int[500];
	private int[] gz = new int[500];
	private int[] time = new int[500];

	private int i = 1;
	private boolean t = false;
	private int chance;
	
	public void paint (Graphics g) { 

		
	  	 for (int i = 0; i < 500; i++) {
	  		 time[i] = i;
	 
	  		 time[i] += 5;
	  		
	  	 }
	  	gx[0] = 0; gy[0] = 0; gz[0] = 0;
	 
	  	
	  	 
	  	 
		super.paintComponents(g);
		
		g.setColor(Color.BLACK);
		//g.fillRect(time[i], 50, 50, 700);
		
		g.setColor(Color.WHITE);
		g.drawString("Graph X", 220, 60);
		g.drawString("Graph Y", 220, 260);
		g.drawString("Graph Z", 220, 460);
		g.setColor(Color.BLUE);
		g.fillRect(510, 80, 110, 100); //horizontal line
		g.setColor(Color.WHITE);
		g.drawString("Current X :" + gx[i], 520, 100);
		g.drawString("Current Y :" + gy[i], 520, 120);
		g.drawString("Current Z :" + gz[i], 520, 140);
		g.drawString("Counter :" + i, 520, 160);
		
		//Line Graphs
		g.fillRect(0, 50, 5, 700); //vertical line
		g.fillRect(ox, oy - 2, 505, 5); //horizontal line
		g.fillRect(ox2, oy2 - 2, 505, 5); //horizontal line
		g.fillRect(ox3, oy3 - 2, 505, 5); //horizontal line
		
		
		g.setColor(Color.RED);
		g.drawLine(ox, oy, time[0], oy - gx[0]); //horizontal line		
		g.drawLine(time[i-1], oy - gx[i - 1], time[i], oy - gx[i]); //horizontal line

		g.setColor(Color.GREEN);
		g.drawLine(ox2, oy2, time[0], oy2 - gy[0]); //horizontal line
		g.drawLine(time[i-1], oy2 - gy[i - 1], time[i], oy2 - gy[i]); //horizontal line
				
		g.setColor(Color.BLUE);
		g.drawLine(ox3, oy3, time[0], oy3 - gz[0]); //horizontal line
		g.drawLine(time[i-1], oy3 - gz[i - 1], time[i], oy3 - gz[i]); //horizontal line	


		
		//Clear screen after i equals 100
		if (i == 499) {
			g.setColor(Color.BLACK);
			g.fillRect(5, 50, 500, 700);
			} 
		
		
		//Fill Graphs
				
		g.setColor(Color.WHITE);
		
		g.drawString("X", 740, 40);
		g.drawString("Y", 840, 40);
		g.drawString("Z", 940, 40);
		
		g.setColor(Color.BLACK);
		g.fillRect(700, 50, 300, 300); //vertical line
				
		g.setColor(Color.RED);
		if (gx[i] > 0) g.fillRect(700, 200 - gx[i], 100, gx[i]); //vertical line
		else g.fillRect(700, 200, 100, -gx[i]);
		
		g.setColor(Color.GREEN);
		if (gy[i] > 0) g.fillRect(800, 200 - gy[i], 100, gy[i]); //vertical line
		else g.fillRect(800, 200, 100, -gy[i]);
		
		g.setColor(Color.BLUE);
		if (gz[i] > 0) g.fillRect(900, 200 - gz[i], 100, gz[i]); //vertical line
		else g.fillRect(900, 200, 100, -gz[i]);
		
		g.setColor(Color.WHITE);
		g.fillRect(700, 198, 300, 5); //horizontal line
		g.fillRect(700, 50, 5, 300); //vertical line
		g.fillRect(800, 50, 5, 300); //vertical line
		g.fillRect(900, 50, 5, 300); //vertical line
		g.fillRect(1000, 50, 5, 300); //vertical line
		
		
	
		if (t == false) init();
		
	}
	
    public void init() {
    	t = true;
  //	setSize(800,600);
       Timer tmr = new Timer(25,new ActionListener(){
          public void actionPerformed(ActionEvent e){
        		
         repaint();
         i+= 1;
         
         if (i >= 500) {i = 1;}
         
         //Temporary values
         gx[i] = (-100 + (int) Math.floor(Math.random() * 200));
         gy[i] = (-100 + (int) Math.floor(Math.random() * 200));
         gz[i] = (-100 + (int) Math.floor(Math.random() * 200));
         
         
      
          }
         }
                 );
           tmr.start();
          // TODO start asynchronous download of heavy resources
      
      // TODO overwrite start(), stop() and destroy() methods


      }

}